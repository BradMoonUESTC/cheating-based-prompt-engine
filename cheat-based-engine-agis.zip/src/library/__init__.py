import sys, os
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from .chatgpt_api import Chat
from .parsing import *
