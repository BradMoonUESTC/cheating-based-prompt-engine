
OPENAI_API_KEY = "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"    # GPT Engine@Dev, us only
# OPENAI_API_KEY = "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"    # GPT Engine@Social

OPENAI_APIS = [
    "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",
    "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"
]

GPT4_API = "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"
